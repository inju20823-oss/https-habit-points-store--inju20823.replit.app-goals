import { useGetPoints } from "@workspace/api-client-react";
import { Loader2 } from "lucide-react";

export function PointsDisplay() {
  const { data, isLoading } = useGetPoints();

  if (isLoading) {
    return <Loader2 className="w-4 h-4 animate-spin text-accent" />;
  }

  return (
    <div className="bg-accent/10 text-accent font-bold px-4 py-2 rounded-2xl flex items-center gap-2 shadow-sm border border-accent/20">
      <span className="text-lg">✨</span>
      <span>{data?.availablePoints ?? 0} 포인트</span>
    </div>
  );
}
