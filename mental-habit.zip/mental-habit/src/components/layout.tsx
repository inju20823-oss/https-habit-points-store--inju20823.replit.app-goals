import { Link, useLocation } from "wouter";
import { Home, Calendar, ShoppingBag, Target } from "lucide-react";
import { ReactNode } from "react";
import { useGetPoints } from "@workspace/api-client-react";

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { data: pointsData } = useGetPoints();

  const navItems = [
    { href: "/", label: "홈", icon: Home },
    { href: "/plan", label: "플랜", icon: Calendar },
    { href: "/shop", label: "상점", icon: ShoppingBag },
    { href: "/goals", label: "목표", icon: Target },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row">
      {/* Sidebar (Desktop) / Top Nav (Mobile) */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t md:border-t-0 md:border-r md:w-64 md:top-0 md:bottom-0 md:flex md:flex-col p-4 shadow-sm pb-safe">
        <div className="hidden md:block mb-8 px-4">
          <h1 className="text-2xl font-bold text-primary flex items-center gap-2">
            <span className="bg-primary/10 text-primary p-2 rounded-xl">🌿</span>
            멘탈해빗
          </h1>
          <p className="text-sm text-muted-foreground mt-1">나를 위한 웰니스 시간</p>
        </div>

        <div className="flex md:flex-col justify-around md:justify-start gap-2 h-full">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex flex-col md:flex-row items-center gap-1 md:gap-3 p-2 md:p-3 rounded-xl transition-all duration-200 ${
                  isActive
                    ? "text-primary bg-primary/10 font-semibold shadow-sm"
                    : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
                }`}
              >
                <item.icon className={`w-5 h-5 md:w-5 md:h-5 ${isActive ? "scale-110" : ""}`} />
                <span className="text-[10px] md:text-base">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-8 pb-24 md:pb-8">
        {/* Mobile Header */}
        <div className="md:hidden flex justify-between items-center mb-6">
          <h1 className="text-xl font-bold text-primary flex items-center gap-2">
            🌿 멘탈해빗
          </h1>
          {pointsData && (
            <div className="bg-accent/10 text-accent font-semibold px-3 py-1 rounded-full flex items-center gap-1 shadow-sm">
              ✨ {pointsData.availablePoints}P
            </div>
          )}
        </div>

        <div className="max-w-4xl mx-auto h-full">
          {children}
        </div>
      </main>
    </div>
  );
}
