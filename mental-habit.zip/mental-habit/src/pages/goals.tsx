import { useState } from "react";
import { 
  useListGoals, 
  useCreateGoal, 
  useUpdateGoal, 
  useDeleteGoal,
  getListGoalsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Target, CheckCircle2, Circle, Trash2, Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

export default function Goals() {
  const { data: goals, isLoading } = useListGoals();
  const createGoal = useCreateGoal();
  const updateGoal = useUpdateGoal();
  const deleteGoal = useDeleteGoal();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newGoal, setNewGoal] = useState({ title: "", description: "" });

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoal.title) return;

    createGoal.mutate(
      { data: { ...newGoal, category: "personal" } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListGoalsQueryKey() });
          setIsAddOpen(false);
          setNewGoal({ title: "", description: "" });
          toast({ title: "목표가 추가되었습니다" });
        },
        onError: () => {
          toast({ title: "목표 추가에 실패했습니다", variant: "destructive" });
        }
      }
    );
  };

  const handleToggleGoal = (id: number, completed: boolean) => {
    updateGoal.mutate(
      { id, data: { completed: !completed } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListGoalsQueryKey() });
        }
      }
    );
  };

  const handleDeleteGoal = (id: number) => {
    deleteGoal.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListGoalsQueryKey() });
          toast({ title: "목표가 삭제되었습니다" });
        }
      }
    );
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const activeGoals = goals?.filter(g => !g.completed) || [];
  const completedGoals = goals?.filter(g => g.completed) || [];

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">장기 목표</h1>
          <p className="text-muted-foreground mt-1">습관이 모여 이루어질 나의 목표들</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 rounded-full">
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">새 목표</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>새로운 목표 추가</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddGoal} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="title">목표</Label>
                <Input 
                  id="title" 
                  value={newGoal.title} 
                  onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })} 
                  placeholder="예: 수면 패턴 정상화"
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">상세 설명 (선택)</Label>
                <Input 
                  id="description" 
                  value={newGoal.description} 
                  onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })} 
                  placeholder="매일 11시에 잠들기" 
                />
              </div>
              <Button type="submit" className="w-full" disabled={createGoal.isPending}>
                {createGoal.isPending ? "추가 중..." : "추가하기"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </header>

      {goals?.length === 0 ? (
        <Card className="border-dashed bg-secondary/30">
          <CardContent className="flex flex-col items-center justify-center p-12 text-center">
            <Target className="w-12 h-12 text-muted-foreground mb-4 opacity-50" />
            <h3 className="text-lg font-medium text-foreground mb-2">설정된 목표가 없습니다</h3>
            <p className="text-muted-foreground max-w-sm">
              작은 습관들이 모여서 이룰 수 있는 나만의 장기 목표를 세워보세요.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-8">
          {activeGoals.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                진행 중인 목표 <span className="bg-primary/10 text-primary text-sm px-2 py-0.5 rounded-full">{activeGoals.length}</span>
              </h2>
              <div className="grid gap-3">
                {activeGoals.map(goal => (
                  <Card key={goal.id} className="group">
                    <CardContent className="p-4 flex items-center gap-4">
                      <button 
                        onClick={() => handleToggleGoal(goal.id, goal.completed)}
                        className="flex-shrink-0 text-muted-foreground hover:text-primary transition-colors"
                      >
                        <Circle className="w-6 h-6" />
                      </button>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-foreground">{goal.title}</h3>
                        {goal.description && (
                          <p className="text-sm text-muted-foreground mt-0.5">{goal.description}</p>
                        )}
                      </div>
                      <button 
                        onClick={() => handleDeleteGoal(goal.id)}
                        className="opacity-0 group-hover:opacity-100 p-2 text-muted-foreground hover:text-destructive transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {completedGoals.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold flex items-center gap-2 opacity-70">
                달성한 목표 <span className="bg-secondary text-secondary-foreground text-sm px-2 py-0.5 rounded-full">{completedGoals.length}</span>
              </h2>
              <div className="grid gap-3">
                {completedGoals.map(goal => (
                  <Card key={goal.id} className="bg-secondary/20 border-transparent">
                    <CardContent className="p-4 flex items-center gap-4 opacity-70">
                      <button 
                        onClick={() => handleToggleGoal(goal.id, goal.completed)}
                        className="flex-shrink-0 text-primary"
                      >
                        <CheckCircle2 className="w-6 h-6" />
                      </button>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-foreground line-through">{goal.title}</h3>
                      </div>
                      <button 
                        onClick={() => handleDeleteGoal(goal.id)}
                        className="p-2 text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
