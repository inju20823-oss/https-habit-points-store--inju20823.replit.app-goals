import { useState, useMemo } from "react";
import { format, isSameDay } from "date-fns";
import { ko } from "date-fns/locale";
import { 
  useListHabits, 
  useListCompletions, 
  useCreateCompletion, 
  useDeleteCompletion,
  useGetMonthlySummary,
  getListHabitsQueryKey,
  getListCompletionsQueryKey,
  getGetPointsQueryKey,
  getGetMonthlySummaryQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Circle, Loader2, TrendingUp, Calendar as CalendarIcon } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function Dashboard() {
  const [today] = useState(new Date());
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const currentMonth = today.getMonth() + 1;
  const currentYear = today.getFullYear();
  const todayStr = format(today, "yyyy-MM-dd");

  const { data: habits, isLoading: habitsLoading } = useListHabits({ month: currentMonth, year: currentYear });
  const { data: completions, isLoading: completionsLoading } = useListCompletions({ date: todayStr });
  const { data: summary, isLoading: summaryLoading } = useGetMonthlySummary({ month: currentMonth, year: currentYear });

  const createCompletion = useCreateCompletion();
  const deleteCompletion = useDeleteCompletion();

  const isLoading = habitsLoading || completionsLoading || summaryLoading;

  const todayCompletions = useMemo(() => {
    if (!completions) return [];
    return completions.filter(c => c.date === todayStr);
  }, [completions, todayStr]);

  const handleToggleHabit = (habitId: number) => {
    const existingCompletion = todayCompletions.find(c => c.habitId === habitId);
    
    if (existingCompletion) {
      deleteCompletion.mutate({ id: existingCompletion.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCompletionsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetPointsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetMonthlySummaryQueryKey() });
        },
        onError: () => {
          toast({ title: "오류가 발생했습니다", variant: "destructive" });
        }
      });
    } else {
      createCompletion.mutate({ data: { habitId, date: todayStr } }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCompletionsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetPointsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetMonthlySummaryQueryKey() });
          toast({ title: "습관 완료! 10 포인트 획득 ✨" });
        },
        onError: () => {
          toast({ title: "오류가 발생했습니다", variant: "destructive" });
        }
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const completedCount = todayCompletions.length;
  const totalCount = habits?.length || 0;
  const progress = totalCount === 0 ? 0 : Math.round((completedCount / totalCount) * 100);

  const chartData = summary?.dailyData.slice(-7).map(d => ({
    name: format(new Date(d.date), "dd일", { locale: ko }),
    완료: d.completedCount
  })) || [];

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-foreground">오늘의 여정</h1>
        <p className="text-muted-foreground mt-1">{format(today, "yyyy년 MM월 dd일 eeee", { locale: ko })}</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gradient-to-br from-primary/10 to-transparent border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              오늘의 달성률
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-2 mb-4">
              <span className="text-4xl font-bold text-primary">{progress}%</span>
              <span className="text-muted-foreground mb-1">{completedCount} / {totalCount} 완료</span>
            </div>
            <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-primary"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5, ease: "easeOut" }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-accent" />
              최근 7일 흐름
            </CardTitle>
          </CardHeader>
          <CardContent className="h-28">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <Tooltip 
                    cursor={{ fill: 'var(--color-secondary)' }}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Bar dataKey="완료" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
                데이터가 없습니다
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-bold text-foreground">해야 할 습관</h2>
        
        {habits?.length === 0 ? (
          <Card className="border-dashed bg-secondary/30">
            <CardContent className="flex flex-col items-center justify-center p-8 text-center">
              <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mb-4">
                <CheckCircle2 className="w-6 h-6 text-muted-foreground" />
              </div>
              <p className="text-foreground font-medium mb-1">등록된 습관이 없습니다</p>
              <p className="text-sm text-muted-foreground mb-4">플랜 탭에서 이번 달 습관을 추가해보세요.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3">
            <AnimatePresence>
              {habits?.map((habit) => {
                const isCompleted = todayCompletions.some(c => c.habitId === habit.id);
                
                return (
                  <motion.div
                    key={habit.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <Card 
                      className={`cursor-pointer transition-colors overflow-hidden ${
                        isCompleted 
                          ? "bg-primary/5 border-primary/20" 
                          : "hover:bg-secondary/50"
                      }`}
                      onClick={() => handleToggleHabit(habit.id)}
                    >
                      <CardContent className="p-4 flex items-center gap-4">
                        <div className="flex-shrink-0">
                          {isCompleted ? (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ type: "spring", stiffness: 300, damping: 20 }}
                            >
                              <CheckCircle2 className="w-6 h-6 text-primary" />
                            </motion.div>
                          ) : (
                            <Circle className="w-6 h-6 text-muted-foreground" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className={`font-medium truncate ${isCompleted ? "text-primary line-through opacity-70" : "text-foreground"}`}>
                            {habit.title}
                          </h3>
                          {habit.description && (
                            <p className="text-xs text-muted-foreground truncate">{habit.description}</p>
                          )}
                        </div>
                        <div className="flex-shrink-0">
                          <span className="text-xs font-medium px-2 py-1 rounded-full bg-secondary text-secondary-foreground">
                            {habit.category}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
