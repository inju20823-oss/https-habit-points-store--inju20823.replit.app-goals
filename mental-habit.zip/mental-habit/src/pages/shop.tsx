import { useState, useMemo } from "react";
import { 
  useListShopItems, 
  useCreatePurchase,
  useGetPoints,
  useListPurchases,
  getListPurchasesQueryKey,
  getGetPointsQueryKey,
  getListShopItemsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ShoppingBag, 
  Loader2, 
  CheckCircle2, 
  Copy, 
  Gift, 
  Clock, 
  AlertCircle, 
  Ticket,
  Eye,
  EyeOff
} from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import type { ShopItem, Purchase } from "@workspace/api-client-react";
import { format } from "date-fns";
import { ko } from "date-fns/locale";

type MainTab = "shop" | "history";
type Category = "전체" | "카페·음식" | "문화·여가" | "쇼핑";

const CATEGORIES: Category[] = ["전체", "카페·음식", "문화·여가", "쇼핑"];

export default function Shop() {
  const [activeTab, setActiveTab] = useState<MainTab>("shop");
  const [selectedCategory, setSelectedCategory] = useState<Category>("전체");
  
  const [selectedItem, setSelectedItem] = useState<ShopItem | null>(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [successPurchase, setSuccessPurchase] = useState<Purchase | null>(null);

  const { data: items, isLoading: itemsLoading } = useListShopItems();
  const { data: purchases, isLoading: purchasesLoading } = useListPurchases();
  const { data: pointsData, isLoading: pointsLoading } = useGetPoints();
  
  const createPurchase = useCreatePurchase();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handlePurchase = () => {
    if (!selectedItem) return;

    if ((pointsData?.availablePoints || 0) < selectedItem.pointCost) {
      toast({ title: "포인트가 부족합니다", variant: "destructive" });
      setSelectedItem(null);
      return;
    }

    if (!/^01[0-9]{8,9}$/.test(phoneNumber)) {
      setPhoneError("유효한 휴대폰 번호를 입력해주세요 (예: 01012345678)");
      return;
    }
    setPhoneError("");

    createPurchase.mutate(
      { data: { shopItemId: selectedItem.id, phoneNumber } },
      {
        onSuccess: (purchase) => {
          queryClient.invalidateQueries({ queryKey: getGetPointsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListPurchasesQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListShopItemsQueryKey() });
          setSelectedItem(null);
          setPhoneNumber("");
          setPhoneError("");
          setSuccessPurchase(purchase);
        },
        onError: (error: any) => {
          const errorMessage = error?.response?.data?.error || "구매에 실패했습니다";
          toast({ title: errorMessage, variant: "destructive" });
          setSelectedItem(null);
          setPhoneNumber("");
          setPhoneError("");
        }
      }
    );
  };

  const filteredItems = useMemo(() => {
    if (!items) return [];
    if (selectedCategory === "전체") return items;
    
    return items.filter(item => {
      const cat = item.category || "";
      if (selectedCategory === "카페·음식") return cat.includes("카페") || cat.includes("음식");
      if (selectedCategory === "문화·여가") return cat.includes("문화") || cat.includes("여가");
      if (selectedCategory === "쇼핑") return cat.includes("쇼핑");
      return false;
    });
  }, [items, selectedCategory]);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: "복사됨!", description: "클립보드에 복사되었습니다." });
    } catch (err) {
      toast({ title: "복사 실패", variant: "destructive" });
    }
  };

  const formatWon = (value: number | null | undefined) => {
    if (value == null) return "0원";
    return new Intl.NumberFormat('ko-KR').format(value) + "원";
  };

  const formatPoints = (value: number | null | undefined) => {
    if (value == null) return "0 P";
    return new Intl.NumberFormat('ko-KR').format(value) + " P";
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      <header className="space-y-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">리워드 상점</h1>
          <p className="text-muted-foreground mt-1">포인트를 모아 원하는 상품으로 교환하세요</p>
        </div>

        {pointsLoading ? (
          <Skeleton className="h-24 w-full rounded-2xl" />
        ) : (
          <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent rounded-2xl p-6 border border-primary/10 flex items-center justify-between shadow-sm relative overflow-hidden">
            <div className="absolute -right-4 -top-4 w-32 h-32 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
            <div className="space-y-1 z-10">
              <p className="text-sm font-medium text-primary/80">사용 가능한 포인트</p>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-extrabold tracking-tight text-primary">
                  {new Intl.NumberFormat('ko-KR').format(pointsData?.availablePoints || 0)}
                </span>
                <span className="text-xl font-bold text-primary/70">P</span>
              </div>
            </div>
            <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center z-10">
              <Gift className="w-8 h-8 text-primary" />
            </div>
          </div>
        )}
      </header>

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as MainTab)} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8 h-12 bg-secondary/50 rounded-xl p-1">
          <TabsTrigger value="shop" className="rounded-lg text-base font-medium transition-all data-[state=active]:bg-background data-[state=active]:shadow-sm">상점</TabsTrigger>
          <TabsTrigger value="history" className="rounded-lg text-base font-medium transition-all data-[state=active]:bg-background data-[state=active]:shadow-sm">구매 내역</TabsTrigger>
        </TabsList>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === "shop" && (
              <div className="space-y-6">
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                        selectedCategory === cat 
                          ? 'bg-foreground text-background shadow-sm' 
                          : 'bg-secondary/50 text-muted-foreground hover:bg-secondary hover:text-foreground'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {itemsLoading ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3, 4, 5, 6].map(i => (
                      <Card key={i} className="overflow-hidden border-none shadow-none bg-secondary/20">
                        <Skeleton className="h-32 w-full rounded-none" />
                        <div className="p-4 space-y-3">
                          <Skeleton className="h-4 w-2/3" />
                          <Skeleton className="h-6 w-1/2" />
                          <Skeleton className="h-10 w-full mt-4" />
                        </div>
                      </Card>
                    ))}
                  </div>
                ) : filteredItems.length === 0 ? (
                  <div className="py-20 text-center flex flex-col items-center bg-secondary/20 rounded-2xl border border-dashed border-secondary">
                    <ShoppingBag className="w-12 h-12 text-muted-foreground/50 mb-4" />
                    <h3 className="text-lg font-medium text-foreground">상품이 없습니다</h3>
                    <p className="text-muted-foreground mt-1 text-sm">해당 카테고리에 등록된 상품이 없습니다.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredItems.map((item) => {
                      const isSoldOut = item.availablePinCount === 0 && item.stock === 0;
                      const hasEnoughPoints = (pointsData?.availablePoints || 0) >= item.pointCost;
                      
                      return (
                        <Card key={item.id} className={`flex flex-col overflow-hidden transition-all hover:shadow-md border-border/50 ${isSoldOut ? 'opacity-70 grayscale-[0.3]' : ''}`}>
                          <CardHeader className="bg-secondary/30 pb-4 relative h-36 flex items-center justify-center">
                            <div className="absolute top-3 left-3 flex gap-2">
                              {isSoldOut && <Badge variant="destructive" className="font-bold">품절</Badge>}
                              <Badge variant="outline" className="bg-background/80 backdrop-blur-sm border-none shadow-sm">{item.category}</Badge>
                            </div>
                            <div className="text-6xl drop-shadow-sm transform hover:scale-110 transition-transform duration-300">{item.emoji}</div>
                          </CardHeader>
                          <CardContent className="pt-5 flex-1 flex flex-col">
                            <div className="text-xs font-bold text-primary mb-1 uppercase tracking-wider">{item.brand}</div>
                            <CardTitle className="text-lg leading-tight mb-2 line-clamp-2 flex-1">{item.title}</CardTitle>
                            
                            <div className="mt-auto space-y-3">
                              <div className="flex items-end justify-between">
                                <span className="text-sm font-medium text-muted-foreground line-through decoration-muted-foreground/50">
                                  {formatWon(item.wonValue)}
                                </span>
                                <div className="inline-flex items-center gap-1.5 text-primary font-bold bg-primary/10 px-2.5 py-1 rounded-md">
                                  <Ticket className="w-4 h-4" />
                                  <span>{formatPoints(item.pointCost)}</span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                          <CardFooter className="pt-0">
                            <Button 
                              className="w-full font-bold h-11" 
                              variant={isSoldOut ? "secondary" : hasEnoughPoints ? "default" : "secondary"}
                              disabled={isSoldOut || !hasEnoughPoints}
                              onClick={() => setSelectedItem(item)}
                            >
                              {isSoldOut ? "품절" : hasEnoughPoints ? "교환하기" : "포인트 부족"}
                            </Button>
                          </CardFooter>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {activeTab === "history" && (
              <div className="space-y-4">
                {purchasesLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <Skeleton key={i} className="h-28 w-full rounded-xl" />
                    ))}
                  </div>
                ) : !purchases || purchases.length === 0 ? (
                  <div className="py-20 text-center flex flex-col items-center bg-secondary/20 rounded-2xl border border-dashed border-secondary">
                    <Clock className="w-12 h-12 text-muted-foreground/50 mb-4" />
                    <h3 className="text-lg font-medium text-foreground">구매 내역이 없습니다</h3>
                    <p className="text-muted-foreground mt-1 text-sm">상점에서 상품을 교환해보세요.</p>
                    <Button variant="outline" className="mt-6" onClick={() => setActiveTab("shop")}>상점 둘러보기</Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {purchases.map(purchase => (
                      <PurchaseHistoryCard 
                        key={purchase.id} 
                        purchase={purchase} 
                        onCopy={copyToClipboard}
                        formatWon={formatWon}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </Tabs>

      {/* Purchase Confirmation Modal */}
      <Dialog open={!!selectedItem} onOpenChange={(open) => !open && setSelectedItem(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">상품 교환</DialogTitle>
          </DialogHeader>
          
          {selectedItem && pointsData && (
            <div className="py-4 space-y-6">
              <div className="flex items-center gap-4 bg-secondary/30 p-4 rounded-xl">
                <div className="text-5xl bg-background rounded-xl p-3 shadow-sm">{selectedItem.emoji}</div>
                <div>
                  <div className="text-xs font-bold text-primary mb-1 uppercase tracking-wider">{selectedItem.brand}</div>
                  <h4 className="font-bold text-lg leading-tight">{selectedItem.title}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{formatWon(selectedItem.wonValue)} 상당</p>
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="phone">수신 전화번호</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="01012345678"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/[^0-9]/g, ''))}
                  maxLength={11}
                  className={phoneError ? "border-destructive" : ""}
                />
                {phoneError && <p className="text-sm text-destructive font-medium">{phoneError}</p>}
                <p className="text-xs text-muted-foreground">기프티콘이 발송될 휴대폰 번호를 숫자만 입력해주세요.</p>
              </div>

              <div className="bg-secondary/20 rounded-xl p-5 space-y-4 border border-secondary/50">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">보유 포인트</span>
                  <span className="font-medium">{formatPoints(pointsData.availablePoints)}</span>
                </div>
                <div className="flex justify-between items-center text-sm text-destructive font-medium">
                  <span>차감 포인트</span>
                  <span>- {formatPoints(selectedItem.pointCost)}</span>
                </div>
                <div className="pt-4 border-t border-border flex justify-between items-center">
                  <span className="font-medium">교환 후 잔여 포인트</span>
                  <span className="font-bold text-lg">{formatPoints(pointsData.availablePoints - selectedItem.pointCost)}</span>
                </div>
              </div>

              <DialogDescription className="text-center text-sm">
                교환 후에는 취소할 수 없습니다.<br />정말 교환하시겠습니까?
              </DialogDescription>
            </div>
          )}

          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setSelectedItem(null)} className="w-full sm:w-1/2 h-12">취소</Button>
            <Button 
              onClick={handlePurchase} 
              disabled={createPurchase.isPending} 
              className="w-full sm:w-1/2 h-12 font-bold"
            >
              {createPurchase.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {createPurchase.isPending ? "처리 중..." : "교환하기"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Purchase Success Modal */}
      <Dialog open={!!successPurchase} onOpenChange={(open) => !open && setSuccessPurchase(null)}>
        <DialogContent className="sm:max-w-md overflow-hidden">
          {successPurchase && (
            <div className="py-6 flex flex-col items-center text-center space-y-6">
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", damping: 15, stiffness: 100 }}
                className="w-20 h-20 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-2"
              >
                <CheckCircle2 className="w-10 h-10" />
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="space-y-2 w-full"
              >
                <h2 className="text-2xl font-bold text-foreground">교환 성공!</h2>
                <p className="text-muted-foreground">선택하신 상품으로 교환되었습니다.</p>
                
                <div className="mt-6 bg-secondary/30 p-5 rounded-xl border border-secondary flex flex-col items-center gap-3">
                  <div className="text-4xl bg-background rounded-full w-16 h-16 flex items-center justify-center shadow-sm mb-1">{successPurchase.shopItemEmoji}</div>
                  <div>
                    <div className="text-xs font-bold text-primary uppercase tracking-wider">{successPurchase.shopItemBrand}</div>
                    <div className="font-bold text-lg">{successPurchase.shopItemTitle}</div>
                  </div>
                  
                  {successPurchase.pinCode && (
                    <div className="w-full mt-4 bg-background p-4 rounded-lg border border-border shadow-inner">
                      <div className="text-xs text-muted-foreground mb-2 font-medium">PIN 번호</div>
                      <div className="flex items-center gap-2">
                        <code className="flex-1 text-lg font-mono font-bold tracking-widest bg-secondary/50 py-2 px-3 rounded text-center">
                          {successPurchase.pinCode}
                        </code>
                        <Button size="icon" variant="outline" className="h-11 w-11 shrink-0" onClick={() => copyToClipboard(successPurchase.pinCode!)}>
                          <Copy className="w-5 h-5" />
                        </Button>
                      </div>
                    </div>
                  )}

                  {successPurchase.barcode && (
                    <div className="w-full mt-2 bg-background p-4 rounded-lg border border-border shadow-inner flex flex-col items-center">
                      <div className="text-xs text-muted-foreground mb-2 font-medium">바코드</div>
                      <div className="font-mono text-3xl tracking-[-0.1em] opacity-80 select-none overflow-hidden text-clip whitespace-nowrap w-full text-center" style={{ fontFamily: 'monospace' }}>
                        |||||||||||||||||||||||||||||
                      </div>
                      <div className="mt-1 font-mono font-medium tracking-widest text-sm">{successPurchase.barcode}</div>
                    </div>
                  )}
                  
                  <div className="text-xs text-muted-foreground mt-2">
                    교환일시: {format(new Date(successPurchase.purchasedAt), 'yyyy년 MM월 dd일 HH:mm', { locale: ko })}
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="w-full pt-4"
              >
                <Button 
                  className="w-full h-12 font-bold" 
                  onClick={() => {
                    setSuccessPurchase(null);
                    setActiveTab("history");
                  }}
                >
                  구매 내역 보기
                </Button>
              </motion.div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PurchaseHistoryCard({ purchase, onCopy, formatWon }: { purchase: Purchase, onCopy: (text: string) => void, formatWon: (v: number|null|undefined) => string }) {
  const [showPin, setShowPin] = useState(false);
  
  return (
    <Card className="overflow-hidden border-border/50 shadow-sm hover:shadow-md transition-all">
      <div className="p-5 flex flex-col sm:flex-row gap-5 items-start sm:items-center">
        <div className="flex gap-4 items-center flex-1">
          <div className="w-16 h-16 bg-secondary/50 rounded-xl flex items-center justify-center text-3xl shadow-inner shrink-0">
            {purchase.shopItemEmoji}
          </div>
          <div>
            <div className="text-xs font-bold text-primary mb-1 uppercase tracking-wider">{purchase.shopItemBrand}</div>
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-bold text-base sm:text-lg leading-tight">{purchase.shopItemTitle}</h4>
              {purchase.status === "SUCCESS" && (
                <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200">발송 완료</Badge>
              )}
              {purchase.status === "PENDING" && (
                <Badge variant="outline" className="bg-yellow-100 text-yellow-700 border-yellow-200 flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  처리 중
                </Badge>
              )}
              {purchase.status === "FAILED" && (
                <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200 flex items-center gap-1">발송 실패</Badge>
              )}
            </div>
            {purchase.status === "FAILED" && purchase.failureReason && (
              <div className="text-xs text-red-600 mb-1 font-medium">{purchase.failureReason}</div>
            )}
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1 font-medium text-foreground bg-secondary/50 px-2 py-0.5 rounded-md">
                <Ticket className="w-3.5 h-3.5" />
                {new Intl.NumberFormat('ko-KR').format(purchase.pointsSpent)} P
              </span>
              <span>•</span>
              <span>{format(new Date(purchase.purchasedAt), 'yyyy.MM.dd', { locale: ko })}</span>
            </div>
          </div>
        </div>
        
        {purchase.status === "SUCCESS" && purchase.pinCode && (
          <div className="w-full sm:w-auto bg-secondary/20 p-3 rounded-xl border border-secondary/50 flex items-center justify-between sm:justify-start gap-3 shrink-0">
            <div className="flex-1 sm:w-48">
              <div className="text-xs text-muted-foreground font-medium mb-1 pl-1">PIN 번호</div>
              <div className="font-mono font-bold tracking-wider text-base bg-background px-3 py-1.5 rounded-md border border-border flex items-center justify-between cursor-pointer" onClick={() => setShowPin(!showPin)}>
                {showPin ? purchase.pinCode : "••••-••••-••••"}
                {showPin ? <EyeOff className="w-4 h-4 text-muted-foreground ml-2" /> : <Eye className="w-4 h-4 text-muted-foreground ml-2" />}
              </div>
            </div>
            <Button size="icon" variant="outline" className="mt-5 h-9 w-9 shrink-0" onClick={() => onCopy(purchase.pinCode!)} title="PIN 번호 복사">
              <Copy className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
