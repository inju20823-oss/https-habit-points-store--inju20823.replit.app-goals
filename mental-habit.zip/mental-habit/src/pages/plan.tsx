import { useState, useMemo } from "react";
import {
  format, getDaysInMonth, startOfMonth, getDay,
  isSameDay, addDays, subDays, isToday, addMonths, subMonths,
} from "date-fns";
import { ko } from "date-fns/locale";
import {
  useListHabits, useListCompletions, useCreateHabit, getListHabitsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, ChevronLeft, ChevronRight, Trash2, CalendarDays, Clock4 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

// ── Types ─────────────────────────────────────────────────────────────────────

interface DailyTask {
  id: string;
  title: string;
  startHour: number;
  endHour: number;   // exclusive upper bound (startHour + duration)
  color: string;
  date: string;      // yyyy-MM-dd
}

const TASK_COLORS = [
  { label: "파랑", value: "#3b82f6" },
  { label: "초록", value: "#22c55e" },
  { label: "보라", value: "#a855f7" },
  { label: "주황", value: "#f97316" },
  { label: "분홍", value: "#ec4899" },
  { label: "하늘", value: "#06b6d4" },
];

const CATEGORY_COLORS: Record<string, string> = {
  action: "#3b82f6",
  bio: "#22c55e",
  stimulus: "#f59e0b",
  custom: "#a855f7",
};

// ── localStorage hook ─────────────────────────────────────────────────────────

function useDailyTasks() {
  const [tasks, setTasks] = useState<DailyTask[]>(() => {
    try { return JSON.parse(localStorage.getItem("mh-daily-tasks") ?? "[]"); }
    catch { return []; }
  });
  const save = (next: DailyTask[]) => {
    setTasks(next);
    localStorage.setItem("mh-daily-tasks", JSON.stringify(next));
  };
  return {
    tasks,
    addTask: (t: Omit<DailyTask, "id">) => save([...tasks, { ...t, id: crypto.randomUUID() }]),
    removeTask: (id: string) => save(tasks.filter(t => t.id !== id)),
    forDate: (d: string) => tasks.filter(t => t.date === d),
  };
}

// ── SVG clock helpers ─────────────────────────────────────────────────────────

const CX = 150, CY = 150;
const OUTER_R = 122, INNER_R = 66, LABEL_R = 140;
const HOUR_DEG = 360 / 24;

function polar(r: number, deg: number) {
  const rad = (deg - 90) * (Math.PI / 180);
  return { x: CX + r * Math.cos(rad), y: CY + r * Math.sin(rad) };
}

function ringArc(startDeg: number, endDeg: number, outerR = OUTER_R, innerR = INNER_R, gap = 1.8) {
  const s1 = polar(outerR, startDeg + gap);
  const e1 = polar(outerR, endDeg - gap);
  const e2 = polar(innerR, endDeg - gap);
  const s2 = polar(innerR, startDeg + gap);
  const large = endDeg - startDeg > 180 ? 1 : 0;
  return [
    `M ${s1.x.toFixed(2)} ${s1.y.toFixed(2)}`,
    `A ${outerR} ${outerR} 0 ${large} 1 ${e1.x.toFixed(2)} ${e1.y.toFixed(2)}`,
    `L ${e2.x.toFixed(2)} ${e2.y.toFixed(2)}`,
    `A ${innerR} ${innerR} 0 ${large} 0 ${s2.x.toFixed(2)} ${s2.y.toFixed(2)}`,
    `Z`,
  ].join(" ");
}

// ── ClockFace ─────────────────────────────────────────────────────────────────

function ClockFace({
  tasks,
  selectedDay,
  onHourClick,
}: {
  tasks: DailyTask[];
  selectedDay: Date;
  onHourClick: (h: number) => void;
}) {
  const now = new Date();
  const isSelectedToday = isSameDay(selectedDay, now);
  const currentAngle = isSelectedToday
    ? (now.getHours() + now.getMinutes() / 60) * HOUR_DEG
    : null;

  // map hour → tasks that cover it
  const taskMap = new Map<number, DailyTask>();
  tasks.forEach(t => {
    for (let h = t.startHour; h < t.endHour && h < 24; h++) {
      if (!taskMap.has(h)) taskMap.set(h, t);
    }
  });

  const majorHours = [0, 6, 12, 18];
  const midHours = [3, 9, 15, 21];
  const minorHours = [1,2,4,5,7,8,10,11,13,14,16,17,19,20,22,23];

  return (
    <svg viewBox="0 0 300 300" className="w-full max-w-[300px] mx-auto select-none drop-shadow-sm">
      {/* Outer background ring */}
      <circle cx={CX} cy={CY} r={OUTER_R + 14} fill="hsl(var(--secondary) / 0.35)" />

      {/* 24 interactive hour segments */}
      {Array.from({ length: 24 }, (_, h) => {
        const start = h * HOUR_DEG;
        const end = (h + 1) * HOUR_DEG;
        const task = taskMap.get(h);
        return (
          <path
            key={h}
            d={ringArc(start, end)}
            fill={task ? task.color : "hsl(var(--secondary) / 0.5)"}
            opacity={task ? 0.82 : 1}
            className="cursor-pointer transition-all hover:brightness-90 hover:scale-105"
            onClick={() => onHourClick(h)}
          />
        );
      })}

      {/* Current time hand */}
      {currentAngle !== null && (() => {
        const tip = polar(OUTER_R - 6, currentAngle);
        const base1 = polar(12, currentAngle + 90);
        const base2 = polar(12, currentAngle - 90);
        return (
          <polygon
            points={`${tip.x.toFixed(1)},${tip.y.toFixed(1)} ${base1.x.toFixed(1)},${base1.y.toFixed(1)} ${base2.x.toFixed(1)},${base2.y.toFixed(1)}`}
            fill="hsl(var(--primary))"
            opacity="0.55"
          />
        );
      })()}

      {/* Inner circle */}
      <circle cx={CX} cy={CY} r={INNER_R - 2} fill="hsl(var(--background))" />

      {/* Inner subtle ring */}
      <circle cx={CX} cy={CY} r={INNER_R - 2} fill="none" stroke="hsl(var(--border))" strokeWidth="1" />

      {/* Center text */}
      {isSelectedToday ? (
        <>
          <text x={CX} y={CY - 9} textAnchor="middle" fontSize="9" fill="hsl(var(--muted-foreground))">현재 시각</text>
          <text x={CX} y={CY + 8} textAnchor="middle" fontSize="15" fontWeight="700" fill="hsl(var(--foreground))" fontFamily="monospace">
            {format(now, "HH:mm")}
          </text>
        </>
      ) : (
        <>
          <text x={CX} y={CY - 8} textAnchor="middle" fontSize="10" fill="hsl(var(--muted-foreground))">
            {format(selectedDay, "M월 d일", { locale: ko })}
          </text>
          <text x={CX} y={CY + 9} textAnchor="middle" fontSize="12" fontWeight="600" fill="hsl(var(--foreground))">
            {format(selectedDay, "EEEE", { locale: ko })}
          </text>
        </>
      )}

      {/* Center dot */}
      <circle cx={CX} cy={CY} r="3.5" fill="hsl(var(--primary))" />

      {/* Major hour labels: 0, 6, 12, 18 */}
      {majorHours.map(h => {
        const pos = polar(LABEL_R, h * HOUR_DEG);
        const label = h === 0 ? "0" : h === 12 ? "12" : String(h);
        return (
          <text key={h} x={pos.x} y={pos.y} textAnchor="middle" dominantBaseline="central"
            fontSize="11" fontWeight="700" fill="hsl(var(--foreground))">
            {label}
          </text>
        );
      })}

      {/* Mid labels: 3, 9, 15, 21 */}
      {midHours.map(h => {
        const pos = polar(LABEL_R, h * HOUR_DEG);
        return (
          <text key={h} x={pos.x} y={pos.y} textAnchor="middle" dominantBaseline="central"
            fontSize="9.5" fontWeight="500" fill="hsl(var(--muted-foreground))">
            {h}
          </text>
        );
      })}

      {/* Minor tick marks */}
      {minorHours.map(h => {
        const inner = polar(OUTER_R + 3, h * HOUR_DEG);
        const outer = polar(OUTER_R + 10, h * HOUR_DEG);
        return (
          <line key={h} x1={inner.x.toFixed(2)} y1={inner.y.toFixed(2)}
            x2={outer.x.toFixed(2)} y2={outer.y.toFixed(2)}
            stroke="hsl(var(--muted-foreground))" strokeWidth="1" opacity="0.4" />
        );
      })}
    </svg>
  );
}

// ── DailyPlanView ─────────────────────────────────────────────────────────────

function DailyPlanView() {
  const [selectedDay, setSelectedDay] = useState(new Date());
  const [addOpen, setAddOpen] = useState(false);
  const [defaultHour, setDefaultHour] = useState(9);
  const [form, setForm] = useState({ title: "", startHour: "9", duration: "1", color: TASK_COLORS[0].value });
  const { tasks, addTask, removeTask, forDate } = useDailyTasks();
  const { toast } = useToast();

  const dateStr = format(selectedDay, "yyyy-MM-dd");
  const dayTasks = forDate(dateStr).sort((a, b) => a.startHour - b.startHour);

  const handleHourClick = (h: number) => {
    setDefaultHour(h);
    setForm(f => ({ ...f, startHour: String(h) }));
    setAddOpen(true);
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    const startHour = parseInt(form.startHour);
    const duration = parseInt(form.duration);
    addTask({
      title: form.title.trim(),
      startHour,
      endHour: Math.min(startHour + duration, 24),
      color: form.color,
      date: dateStr,
    });
    setAddOpen(false);
    setForm({ title: "", startHour: "9", duration: "1", color: TASK_COLORS[0].value });
    toast({ title: "일정이 추가되었습니다" });
  };

  return (
    <div className="space-y-6">
      {/* Day navigation */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="icon" onClick={() => setSelectedDay(d => subDays(d, 1))}>
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <div className="text-center">
          <div className="text-xl font-bold">
            {format(selectedDay, "yyyy년 M월 d일", { locale: ko })}
          </div>
          <div className="text-sm text-muted-foreground">
            {format(selectedDay, "EEEE", { locale: ko })}
            {isToday(selectedDay) && (
              <Badge className="ml-2 text-xs py-0 h-5 bg-primary/10 text-primary border-primary/20">오늘</Badge>
            )}
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setSelectedDay(d => addDays(d, 1))}>
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>

      {/* Clock + Add button */}
      <div className="relative">
        <ClockFace tasks={dayTasks} selectedDay={selectedDay} onHourClick={handleHourClick} />
        <div className="flex justify-center mt-3">
          <Button size="sm" variant="outline" className="gap-1.5 rounded-full"
            onClick={() => { setForm(f => ({ ...f, startHour: "9" })); setAddOpen(true); }}>
            <Plus className="w-3.5 h-3.5" />
            일정 추가
          </Button>
        </div>
      </div>

      {/* Clock legend hint */}
      <p className="text-center text-xs text-muted-foreground">
        시계 구역을 클릭해 해당 시간에 일정을 추가하세요
      </p>

      {/* Task list */}
      {dayTasks.length > 0 ? (
        <div className="space-y-2">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">오늘의 일정</h3>
          <div className="space-y-2">
            {dayTasks.map(task => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 8 }}
                className="flex items-center gap-3 p-3 rounded-xl border border-border/50 bg-card hover:bg-secondary/20 transition-colors group"
              >
                <div className="w-1 self-stretch rounded-full" style={{ backgroundColor: task.color }} />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{task.title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {String(task.startHour).padStart(2, "0")}:00 – {String(Math.min(task.endHour, 24)).padStart(2, "0")}:00
                  </div>
                </div>
                <Button size="icon" variant="ghost"
                  className="w-7 h-7 opacity-0 group-hover:opacity-100 transition-opacity shrink-0 text-muted-foreground hover:text-destructive"
                  onClick={() => removeTask(task.id)}>
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      ) : (
        <div className="py-8 text-center text-muted-foreground text-sm bg-secondary/20 rounded-2xl border border-dashed border-secondary">
          이 날의 일정이 없습니다.<br />시계 구역을 클릭하거나 + 버튼으로 추가해보세요.
        </div>
      )}

      {/* Add task dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>일정 추가</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleAdd} className="space-y-4 pt-2">
            <div className="space-y-2">
              <Label>일정 이름</Label>
              <Input
                autoFocus
                placeholder="예: 아침 명상, 운동, 독서"
                value={form.title}
                onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>시작 시간</Label>
                <Select value={form.startHour} onValueChange={v => setForm(f => ({ ...f, startHour: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent className="max-h-48">
                    {Array.from({ length: 24 }, (_, h) => (
                      <SelectItem key={h} value={String(h)}>
                        {String(h).padStart(2, "0")}:00
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>소요 시간</Label>
                <Select value={form.duration} onValueChange={v => setForm(f => ({ ...f, duration: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1시간</SelectItem>
                    <SelectItem value="2">2시간</SelectItem>
                    <SelectItem value="3">3시간</SelectItem>
                    <SelectItem value="4">4시간</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>색상</Label>
              <div className="flex gap-2">
                {TASK_COLORS.map(c => (
                  <button
                    key={c.value}
                    type="button"
                    className={`w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 ${form.color === c.value ? "border-foreground scale-110" : "border-transparent"}`}
                    style={{ backgroundColor: c.value }}
                    onClick={() => setForm(f => ({ ...f, color: c.value }))}
                    title={c.label}
                  />
                ))}
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setAddOpen(false)}>취소</Button>
              <Button type="submit">추가하기</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── MonthlyCalendarView ───────────────────────────────────────────────────────

const DAY_LABELS = ["일", "월", "화", "수", "목", "금", "토"];

function MonthlyCalendarView({
  currentDate,
  onPrev,
  onNext,
}: {
  currentDate: Date;
  onPrev: () => void;
  onNext: () => void;
}) {
  const month = currentDate.getMonth() + 1;
  const year = currentDate.getFullYear();

  const { data: habits, isLoading: habitsLoading } = useListHabits({ month, year });
  const { data: completions, isLoading: completionsLoading } = useListCompletions({ month, year });

  const calendarWeeks = useMemo(() => {
    const firstDay = startOfMonth(currentDate);
    const totalDays = getDaysInMonth(currentDate);
    const startDow = getDay(firstDay); // 0=Sun

    const cells: (Date | null)[] = [
      ...Array(startDow).fill(null),
      ...Array.from({ length: totalDays }, (_, i) => addDays(firstDay, i)),
    ];

    // pad to full weeks
    while (cells.length % 7 !== 0) cells.push(null);

    const weeks: (Date | null)[][] = [];
    for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));
    return weeks;
  }, [currentDate]);

  const completionMap = useMemo(() => {
    const map = new Map<string, Set<number>>();
    completions?.forEach(c => {
      if (!map.has(c.date)) map.set(c.date, new Set());
      map.get(c.date)!.add(c.habitId);
    });
    return map;
  }, [completions]);

  const getDayStatus = (date: Date) => {
    const key = format(date, "yyyy-MM-dd");
    const done = completionMap.get(key)?.size ?? 0;
    const total = habits?.length ?? 0;
    return { done, total, ratio: total > 0 ? done / total : 0 };
  };

  const loading = habitsLoading || completionsLoading;

  return (
    <div className="space-y-4">
      {/* Month nav */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="icon" onClick={onPrev}><ChevronLeft className="w-5 h-5" /></Button>
        <h2 className="text-xl font-bold">{format(currentDate, "yyyy년 M월")}</h2>
        <Button variant="ghost" size="icon" onClick={onNext}><ChevronRight className="w-5 h-5" /></Button>
      </div>

      {loading ? (
        <div className="py-16 text-center text-muted-foreground">불러오는 중...</div>
      ) : (
        <Card className="overflow-hidden border-border/50">
          <CardContent className="p-0">
            {/* Day of week header */}
            <div className="grid grid-cols-7 border-b border-border/50 bg-secondary/30">
              {DAY_LABELS.map((d, i) => (
                <div
                  key={d}
                  className={`py-2.5 text-center text-xs font-semibold tracking-wide
                    ${i === 0 ? "text-red-500" : i === 6 ? "text-blue-500" : "text-muted-foreground"}`}
                >
                  {d}
                </div>
              ))}
            </div>

            {/* Calendar grid */}
            {calendarWeeks.map((week, wi) => (
              <div key={wi} className={`grid grid-cols-7 ${wi < calendarWeeks.length - 1 ? "border-b border-border/30" : ""}`}>
                {week.map((day, di) => {
                  if (!day) {
                    return <div key={di} className="min-h-[72px] bg-secondary/10 p-1" />;
                  }

                  const today = isToday(day);
                  const { done, total, ratio } = getDayStatus(day);
                  const hasHabits = total > 0;
                  const allDone = hasHabits && done === total;
                  const partial = hasHabits && done > 0 && done < total;

                  const bgClass = allDone
                    ? "bg-emerald-50 dark:bg-emerald-950/30"
                    : partial
                    ? "bg-amber-50 dark:bg-amber-950/20"
                    : "";

                  const dots = habits?.slice(0, 7).map(h => {
                    const key = format(day, "yyyy-MM-dd");
                    const isDone = completionMap.get(key)?.has(h.id) ?? false;
                    const color = CATEGORY_COLORS[h.category] ?? "#94a3b8";
                    return { id: h.id, isDone, color };
                  });

                  return (
                    <motion.div
                      key={day.toISOString()}
                      whileHover={{ scale: 1.02 }}
                      className={`min-h-[72px] p-1.5 relative cursor-default
                        ${bgClass}
                        ${di < 6 ? "border-r border-border/30" : ""}
                        ${di === 0 ? "text-red-500" : di === 6 ? "text-blue-500" : ""}
                        transition-colors`}
                    >
                      {/* Date number */}
                      <div className="flex items-start justify-between mb-1">
                        <span className={`text-xs font-semibold leading-none rounded-full flex items-center justify-center
                          ${today ? "w-6 h-6 bg-primary text-primary-foreground" : ""}`}>
                          {format(day, "d")}
                        </span>
                        {allDone && (
                          <span className="text-[9px] font-bold text-emerald-600 leading-none">완료</span>
                        )}
                      </div>

                      {/* Completion dots */}
                      {dots && dots.length > 0 && (
                        <div className="flex flex-wrap gap-[3px] mt-1">
                          {dots.map(dot => (
                            <div
                              key={dot.id}
                              className="w-[7px] h-[7px] rounded-full transition-opacity"
                              style={{
                                backgroundColor: dot.isDone ? dot.color : "transparent",
                                border: `1.5px solid ${dot.color}`,
                                opacity: dot.isDone ? 1 : 0.4,
                              }}
                            />
                          ))}
                        </div>
                      )}

                      {/* Progress bar at bottom */}
                      {hasHabits && (
                        <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-secondary/40 overflow-hidden">
                          <div
                            className="h-full transition-all"
                            style={{
                              width: `${ratio * 100}%`,
                              backgroundColor: allDone ? "#22c55e" : partial ? "#f59e0b" : "transparent",
                            }}
                          />
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Habit legend */}
      {habits && habits.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {habits.slice(0, 7).map(h => (
            <div key={h.id} className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <div className="w-2.5 h-2.5 rounded-full"
                style={{ backgroundColor: CATEGORY_COLORS[h.category] ?? "#94a3b8" }} />
              <span className="truncate max-w-[100px]">{h.title}</span>
            </div>
          ))}
          {habits.length > 7 && (
            <span className="text-xs text-muted-foreground">+{habits.length - 7}개</span>
          )}
        </div>
      )}

      {/* Habit count summary */}
      {habits && habits.length === 0 && (
        <div className="py-8 text-center text-sm text-muted-foreground bg-secondary/20 rounded-2xl border border-dashed border-secondary">
          이 달에 등록된 습관이 없습니다.
        </div>
      )}
    </div>
  );
}

// ── Main Plan page ────────────────────────────────────────────────────────────

export default function Plan() {
  const [planTab, setPlanTab] = useState<"monthly" | "daily">("monthly");
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newHabit, setNewHabit] = useState({ title: "", description: "", category: "action" });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const createHabit = useCreateHabit();

  const month = currentDate.getMonth() + 1;
  const year = currentDate.getFullYear();

  const handleAddHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabit.title) return;
    createHabit.mutate(
      { data: { ...newHabit, month, year } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListHabitsQueryKey() });
          setIsAddOpen(false);
          setNewHabit({ title: "", description: "", category: "action" });
          toast({ title: "새로운 습관이 추가되었습니다" });
        },
        onError: () => toast({ title: "습관 추가에 실패했습니다", variant: "destructive" }),
      }
    );
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto pb-12">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">플랜</h1>
          <p className="text-muted-foreground mt-1">
            {planTab === "monthly" ? "나의 습관 기록을 달력으로 확인하세요" : "하루를 시계처럼 계획하세요"}
          </p>
        </div>
        {planTab === "monthly" && (
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <Button className="gap-2 rounded-full" onClick={() => setIsAddOpen(true)}>
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">새 습관</span>
            </Button>
            <DialogContent>
              <DialogHeader><DialogTitle>새로운 습관 추가</DialogTitle></DialogHeader>
              <form onSubmit={handleAddHabit} className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="title">습관 이름</Label>
                  <Input id="title" value={newHabit.title}
                    onChange={e => setNewHabit({ ...newHabit, title: e.target.value })}
                    placeholder="예: 아침 10분 명상" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="desc">상세 설명 (선택)</Label>
                  <Input id="desc" value={newHabit.description}
                    onChange={e => setNewHabit({ ...newHabit, description: e.target.value })}
                    placeholder="편안한 호흡 유지하기" />
                </div>
                <div className="space-y-2">
                  <Label>카테고리</Label>
                  <Select value={newHabit.category} onValueChange={v => setNewHabit({ ...newHabit, category: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="action">행동</SelectItem>
                      <SelectItem value="bio">생리적</SelectItem>
                      <SelectItem value="stimulus">자극</SelectItem>
                      <SelectItem value="custom">기타</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full" disabled={createHabit.isPending}>
                  {createHabit.isPending ? "추가 중..." : "추가하기"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </header>

      <Tabs value={planTab} onValueChange={v => setPlanTab(v as "monthly" | "daily")}>
        <TabsList className="grid w-full grid-cols-2 h-11 bg-secondary/50 rounded-xl p-1">
          <TabsTrigger value="monthly" className="rounded-lg gap-1.5 font-medium data-[state=active]:bg-background data-[state=active]:shadow-sm">
            <CalendarDays className="w-4 h-4" />
            월별 플랜
          </TabsTrigger>
          <TabsTrigger value="daily" className="rounded-lg gap-1.5 font-medium data-[state=active]:bg-background data-[state=active]:shadow-sm">
            <Clock4 className="w-4 h-4" />
            일간 플랜
          </TabsTrigger>
        </TabsList>

        <AnimatePresence mode="wait">
          <motion.div
            key={planTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="mt-6"
          >
            <TabsContent value="monthly" forceMount className={planTab !== "monthly" ? "hidden" : ""}>
              <MonthlyCalendarView
                currentDate={currentDate}
                onPrev={() => setCurrentDate(d => subMonths(d, 1))}
                onNext={() => setCurrentDate(d => addMonths(d, 1))}
              />
            </TabsContent>
            <TabsContent value="daily" forceMount className={planTab !== "daily" ? "hidden" : ""}>
              <DailyPlanView />
            </TabsContent>
          </motion.div>
        </AnimatePresence>
      </Tabs>
    </div>
  );
}
